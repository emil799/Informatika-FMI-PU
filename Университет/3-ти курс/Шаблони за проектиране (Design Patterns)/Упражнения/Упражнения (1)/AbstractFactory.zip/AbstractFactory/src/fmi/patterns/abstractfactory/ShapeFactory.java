package fmi.patterns.abstractfactory;

public class ShapeFactory extends AbstractFactory {

	@Override
	public IShape getShape(final String shapeType) {
		final IShape result;
		if (shapeType.equalsIgnoreCase("CIRCLE")) {
			result = new Circle();
		} else if (shapeType.equalsIgnoreCase("RECTANGLE")) {
			result = new Rectangle();
		} else if (shapeType.equalsIgnoreCase("SQUARE")) {
			result = new Square();
		} else {
			result = null;
		}
		return result;
	}

	@Override
	public IColor getColor(final String color) {
		return null;
	}
}