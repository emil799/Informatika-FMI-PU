package fmi.patterns.abstractfactory;

public final class FactoryProducer {
	private FactoryProducer() {

	}

	public static AbstractFactory getFactory(final String choice) {
		final AbstractFactory factory;
		if ("SHAPE".equalsIgnoreCase(choice)) {
			factory = new ShapeFactory();
		} else if ("COLOR".equalsIgnoreCase(choice)) {
			factory = new ColorFactory();
		} else {
			factory = null;
		}
		return factory;
	}
}