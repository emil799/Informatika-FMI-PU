package fmi.patterns.abstractfactory;

public interface IShape {
	void draw();
}