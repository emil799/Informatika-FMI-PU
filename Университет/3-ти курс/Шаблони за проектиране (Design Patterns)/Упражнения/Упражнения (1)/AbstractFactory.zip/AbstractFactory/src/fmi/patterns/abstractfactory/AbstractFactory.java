package fmi.patterns.abstractfactory;

public abstract class AbstractFactory {
	
	public abstract IColor getColor(final String color);
	public abstract IShape getShape(final String shape);
	
}