package fmi.patterns.abstractfactory;

public class ColorFactory extends AbstractFactory {

	@Override
	public IShape getShape(final String shapeType) {
		return null;
	}

	@Override
	public IColor getColor(final String color) {
		final IColor result;
		if ("RED".equalsIgnoreCase(color)) {
			result = new Red();
		} else if ("GREEN".equalsIgnoreCase(color)) {
			result = new Green();
		} else if ("BLUE".equalsIgnoreCase(color)) {
			result = new Blue();
		} else {
			result = null;
		}
		return result;
	}
}