package fmi.patterns.abstractfactory;

public interface IColor {
	void fill();
}