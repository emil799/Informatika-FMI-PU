package fmi;

public interface Sound {
	void play();
}
