package fmi.patterns.abstractfactory;

public interface Shape {
	void draw();
}