package fmi.patterns.abstractfactory;

public interface Color {
	void fill();
}