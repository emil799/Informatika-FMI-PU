package fmi;

public interface ItemElement {
	public int accept(ShoppingCartVisitor visitor);
}
