package com;

public interface Shape {
	   void draw();
}