package fmi;

public interface Container {
	public Iterator getIterator();
}
