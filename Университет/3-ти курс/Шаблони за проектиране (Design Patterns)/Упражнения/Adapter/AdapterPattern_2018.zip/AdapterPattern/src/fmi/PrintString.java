package fmi;

public class PrintString {
	public void print(String s){
		System.out.println(s);
	}
}
