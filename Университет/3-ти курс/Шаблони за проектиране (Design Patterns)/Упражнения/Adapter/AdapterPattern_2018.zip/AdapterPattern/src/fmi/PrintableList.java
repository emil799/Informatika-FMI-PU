package fmi;
import java.util.ArrayList;

public interface PrintableList {
	void printList(ArrayList<String> list);
}
