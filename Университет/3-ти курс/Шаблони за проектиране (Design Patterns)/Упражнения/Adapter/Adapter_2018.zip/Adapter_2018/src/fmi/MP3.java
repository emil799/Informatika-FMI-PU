package fmi;

public class MP3 implements MediaPlayer {

	@Override
	public void play(String filename) {
		System.out.println("Playing mp3 file " + filename);

	}

}
