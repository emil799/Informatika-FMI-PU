package fmi;

public interface MediaPlayer {
	void play(String filename);
}
