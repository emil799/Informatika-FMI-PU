package fmi;

public interface MediaPackage {
	void playFile(String filename);
}
