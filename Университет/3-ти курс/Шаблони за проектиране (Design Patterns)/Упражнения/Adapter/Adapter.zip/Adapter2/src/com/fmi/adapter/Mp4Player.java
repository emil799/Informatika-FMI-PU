package com.fmi.adapter;


public class Mp4Player implements IAdvancetMediaPlayer {

	@Override
	public void playVlc() {
	
	}

	@Override
	public void playMp4() {
		System.out.println("Mp4Player");
	}

}
