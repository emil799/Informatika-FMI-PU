package com.fmi.adapter;

public class VlcPlayer implements IAdvancetMediaPlayer {

	@Override
	public void playVlc() {
		System.out.println("VlcPlayer");

	}

	@Override
	public void playMp4() {
	}

}
