package com.fmi.adapter;
public interface IAdvancetMediaPlayer {
	void playVlc();

	void playMp4();
}
