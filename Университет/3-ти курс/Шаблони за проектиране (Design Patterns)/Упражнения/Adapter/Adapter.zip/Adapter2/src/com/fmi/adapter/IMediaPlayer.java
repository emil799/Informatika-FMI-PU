package com.fmi.adapter;

public interface IMediaPlayer {
	void play();
}
