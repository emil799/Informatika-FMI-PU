package fmi;

public class CowCheese extends FarmProduct {

	@Override
	public void prepare() {
		System.out.println("Preparing cow cheese");
	}

}
