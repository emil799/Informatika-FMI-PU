package fmi;

public class GoatCheese extends FarmProduct {

	@Override
	public void prepare() {
		System.out.println("Preparing goat cheese");
	}

}
