package fmi;

public interface Car {
	void create();
}
