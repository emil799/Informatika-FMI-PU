package fmi;

public class Lamborghini implements Car {

	@Override
	public void create() {
		
		System.out.println("Car: Lambo");

	}

}
