package fmi;

public class Lada implements Car {

	@Override
	public void create() {
		System.out.println("Car: Lada");
	}
	
}
