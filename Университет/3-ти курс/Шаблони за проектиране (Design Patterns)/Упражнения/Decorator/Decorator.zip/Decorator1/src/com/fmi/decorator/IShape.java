package com.fmi.decorator;

public interface IShape {
	
	/**
	 * Draw a shape.
	 */
	void draw();
}
