package fmi;

public interface State {
	public void executeAction(Context context);
}
