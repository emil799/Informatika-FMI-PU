package fmi;

public interface Command {
	public void execute();
}
