package bridgePattern;

//implementor
interface Workshop {
    abstract public void work();
}
