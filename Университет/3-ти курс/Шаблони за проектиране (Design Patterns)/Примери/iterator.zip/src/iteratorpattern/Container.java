package iteratorpattern;

public interface Container {
	public Iterator getIterator();
}
