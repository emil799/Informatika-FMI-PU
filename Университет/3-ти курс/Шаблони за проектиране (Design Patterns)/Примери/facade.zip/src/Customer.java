 public class Customer
  {
    private String _name;
 
    // Constructor
    public Customer(String name)
    {
      this._name = name;
    }
 
    // Gets the name
    public String Name()
    {
      return this._name;
    }
  }