public class Credit
  {
    public boolean HasGoodCredit(Customer c)
    {
      System.out.println("Check credit for " + c.Name());
      return true;
    }
  }