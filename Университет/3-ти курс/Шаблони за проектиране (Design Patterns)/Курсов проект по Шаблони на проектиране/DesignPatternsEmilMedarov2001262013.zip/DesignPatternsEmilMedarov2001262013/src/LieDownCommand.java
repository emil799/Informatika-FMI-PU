
public class LieDownCommand implements Command{
	private ExerciseParticipant participant;
    
    public LieDownCommand(ExerciseParticipant participant) {
        this.participant = participant;
    }
    
    @Override
    public void execute() {
        participant.doLieDown();
    }
}
