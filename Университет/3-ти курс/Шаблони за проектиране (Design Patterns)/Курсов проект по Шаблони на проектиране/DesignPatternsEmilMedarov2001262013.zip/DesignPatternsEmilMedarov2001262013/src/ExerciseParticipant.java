import java.util.Random;

public class ExerciseParticipant {
	private String position;
    
    public String getPosition() {
        return position;
    }
    
    public void setPosition(String position) {
        this.position = position;
    }
    
    public void changePosition() {
        Random random = new Random();
        int num = random.nextInt(2);
        if (num == 0) {
            position = "lie down";
        } else {
            position = "stand up";
        }
    }
    
    public void doLieDown() {
        position = "lie down";
    }
    
    public void doStandUp() {
        position = "stand up";
    }
}
