
public class Trainer implements Observer{
	private ExerciseParticipant participant;
    
    public Trainer(ExerciseParticipant participant) {
        this.participant = participant;
    }
    @Override
    public void update(String position) {
        if (position.equals("lie down")) {
            System.out.println("Trainer: Lie down");
            Command lieDownCommand = new LieDownCommand(participant);
            lieDownCommand.execute();
        } else {
            System.out.println("Trainer: Stand up");
            Command standUpCommand = new StandUpCommand(participant);
            standUpCommand.execute();
        }
    }
}
