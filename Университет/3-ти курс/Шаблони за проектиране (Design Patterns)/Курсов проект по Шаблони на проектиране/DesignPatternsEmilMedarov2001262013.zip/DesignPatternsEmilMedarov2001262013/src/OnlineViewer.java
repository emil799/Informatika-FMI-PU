public class OnlineViewer implements Observer {
    private String name;
    private ExerciseParticipant participant;
    
    public OnlineViewer(String name, ExerciseParticipant participant) {
        this.name = name;
        this.participant = participant;
    }
    
    @Override
    public void update(String position) {
        if (position.equals("lie down")) {
            System.out.println(name + ": Lie down");
            Command lieDownCommand = new LieDownCommand(participant);
            lieDownCommand.execute();
        } else {
            System.out.println(name + ": Stand up");
            Command standUpCommand = new StandUpCommand(participant);
            standUpCommand.execute();
        }
    }
}