public class FitnessTrainingMain {
    public static void main(String[] args) {
        // create the exercise participant
        ExerciseParticipant participant = new ExerciseParticipant();
        
        // create the fitness instructor and register the trainer and online viewers
        FitnessInstructor instructor = new FitnessInstructor(participant);
        Trainer trainer = new Trainer(participant);
        instructor.registerObserver(trainer);
        
        OnlineViewer viewer1 = new OnlineViewer("Viewer 1", participant);
        OnlineViewer viewer2 = new OnlineViewer("Viewer 2", participant);
        OnlineViewer viewer3 = new OnlineViewer("Viewer 3", participant);
        instructor.registerObserver(viewer1);
        instructor.registerObserver(viewer2);
        instructor.registerObserver(viewer3);
        
        // simulate the exercise training
        instructor.changePosition(); // lie down
        instructor.changePosition(); // stand up
        instructor.changePosition(); // lie down
        instructor.changePosition(); // stand up
    }
}