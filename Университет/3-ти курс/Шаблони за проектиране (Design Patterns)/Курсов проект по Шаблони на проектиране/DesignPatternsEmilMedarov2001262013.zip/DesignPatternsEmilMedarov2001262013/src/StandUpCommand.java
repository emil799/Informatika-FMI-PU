
public class StandUpCommand implements Command{
	private ExerciseParticipant participant;
    
    public StandUpCommand(ExerciseParticipant participant) {
        this.participant = participant;
    }
    
    @Override
    public void execute() {
        participant.doStandUp();
    }
}
