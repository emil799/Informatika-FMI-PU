import java.util.ArrayList;
import java.util.List;


public class FitnessInstructor implements Subject{
	private ExerciseParticipant participant;
    private List<Observer> observers;
    
    public FitnessInstructor(ExerciseParticipant participant) {
        this.participant = participant;
        this.observers = new ArrayList<>();
    }
    
    public void changePosition() {
        participant.changePosition();
        notifyObservers();
    }
    
    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }
    
    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    
    @Override
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(participant.getPosition());
        }
    }
}
