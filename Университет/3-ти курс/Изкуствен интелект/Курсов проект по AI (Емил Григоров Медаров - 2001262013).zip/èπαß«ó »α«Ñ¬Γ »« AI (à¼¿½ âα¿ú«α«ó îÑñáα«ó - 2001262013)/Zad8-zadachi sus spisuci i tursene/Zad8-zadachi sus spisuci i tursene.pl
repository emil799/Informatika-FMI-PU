% Define the possible cities and participants
city(sofia).
city(plovdiv).
city(pleven).
city(veliko_tarnovo).
city(ruse).

participant(ivan).
participant(todor).
participant(alexander).
participant(nikolai).
participant(victor).

% Define the relationships between the participants and the cities
lives_in(ivan, City) :-
    city(City),
    City \= sofia,
    City \= ruse.

lives_in(todor, City) :-
    city(City),
    City \= plovdiv.

lives_in(alexander, City) :-
    city(City).

lives_in(nikolai, City) :-
    city(City),
    City \= plovdiv.

lives_in(victor, City) :-
    city(City).

% Define the constraints on the seating arrangement
seating_arrangement(Participants) :-
    permutation(Participants, [ivan, todor, alexander, nikolai, victor]),
    nextto(ruse, viktor, Participants),
    nextto(veliko_tarnovo, alexander, Participants),
    between(1, 5, Pos),
    nth1(Pos, Participants, alexander),
    nth1(Left, Participants, veliko_tarnovo), Left is Pos-1, Left > 0,
    nth1(Right, Participants, veliko_tarnovo), Right is Pos+1, Right =< 5,
    nth1(PlovdivPos, Participants, plovdiv),
    (PlovdivPos =:= 1, (IvanPos =:= 2 ; TodorPos =:= 2)) ;
    (PlovdivPos =:= 5, (IvanPos =:= 4 ; TodorPos =:= 4)) ;
    (PlovdivPos =:= 2, (IvanPos =:= 1 ; TodorPos =:= 3)) ;
    (PlovdivPos =:= 4, (IvanPos =:= 3 ; TodorPos =:= 5)),
    nth1(IvanPos, Participants, ivan), IvanPos \= 1, IvanPos \= 3,
    nth1(TodorPos, Participants, todor), TodorPos \= 1, TodorPos \= 5,
    nth1(SofiaPos, Participants, sofia),
    nth1(RusePos, Participants, ruse),
    nextto(SofiaPos, RusePos, Participants),
    nth1(AlexPos, Participants, alexander),
    (AlexPos =:= 2 ; AlexPos =:= 4),
    nth1(VelikoTarnovoPos, Participants, veliko_tarnovo),
    (VelikoTarnovoPos =:= AlexPos-1 ; VelikoTarnovoPos =:= AlexPos+1),
    nth1(NikolaiPos, Participants, nikolai),
    lives_in(nikolai, NikolaiCity),
    NikolaiCity \= plovdiv.

% Define the predicate to find the solution
solve(Participants) :-
    seating_arrangement(Participants),
    writeln('Solution:'),
    writeln('Participant         City'),
    writeln('------------------------'),
    print_row(ivan, Participants),
    print_row(todor, Participants),
    print_row(alexander, Participants),
    print_row(nikolai, Participants),
    print_row(victor, Participants).

% Define the predicate to print a row of the table
print_row(Participant, Participants) :-
    lives
