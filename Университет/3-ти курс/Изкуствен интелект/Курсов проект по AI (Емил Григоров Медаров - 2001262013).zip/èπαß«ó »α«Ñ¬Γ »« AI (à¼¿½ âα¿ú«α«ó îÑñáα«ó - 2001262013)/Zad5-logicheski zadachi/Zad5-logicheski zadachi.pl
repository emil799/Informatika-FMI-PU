% Define the possible cities and subjects
city(sofia).
city(plovdiv).
city(varna).

subject(chemistry).
subject(biology).
subject(math).

% Define the relationships between the people, cities, and subjects
% Vesela does not study in Sofia
does_not_study(vesela, sofia, _).

% Mima is not in Plovdiv
is_not_in(mima, plovdiv).

% The one in Sofia doesn't study math
studies(_, sofia, Subject) :- Subject \= math.

% She is studying chemistry in Plovdiv
studies(_, plovdiv, chemistry).

% Mima doesn't like biology
does_not_like(mima, biology).

% Mima sees the sunset in the sea every day
sees_sunset(mima, varna).

% Define a predicate to find the solution
find_solution(Vesela, Mima, Pepa) :-
    % Vesela, Mima, and Pepa study different subjects
    subject(VeselaSubject), subject(MimaSubject), subject(PepaSubject),
    all_different([VeselaSubject, MimaSubject, PepaSubject]),

    % Vesela, Mima, and Pepa study in different cities
    city(VeselaCity), city(MimaCity), city(PepaCity),
    all_different([VeselaCity, MimaCity, PepaCity]),

    % Apply the relationships
    studies(Vesela, VeselaCity, VeselaSubject),
    studies(Mima, MimaCity, MimaSubject),
    studies(Pepa, PepaCity, PepaSubject),
    does_not_study(Vesela, _, math),
    is_not_in(Mima, plovdiv),
    does_not_like(Mima, biology),
    sees_sunset(Mima, varna).

% Define a helper predicate to check that all elements in a list are different
all_different([]).
all_different([H | T]) :- not(member(H, T)), all_different(T).
