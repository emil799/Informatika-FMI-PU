% Define the boys
boy(ivan).
boy(peter).
boy(vasil).

% Define the possible containers
container(basket).
container(bucket).
container(plastic_bag).

% Define the facts about who carried what
carried_in(ivan, bucket).
carried_in(peter, plastic_bag).
carried_in(vasil, basket).

% Define the rules about who didn't carry what
did_not_carry(Ivan, Container) :-
  boy(Ivan),
  container(Container),
  \+ carried_in(Ivan, Container),
  \+ (Ivan = peter, (Container = basket ; Container = plastic_bag)).

did_not_carry(peter, basket).
did_not_carry(peter, plastic_bag).

% Define the goal of the program
?- did_not_carry(ivan, basket),
   did_not_carry(peter, _),
   carried_in(vasil, Container).
