% Define the possible residents
resident(simo).
resident(petko).
resident(ivan).
resident(theo).

% Define the possible floors
floor(1).
floor(2).
floor(3).
floor(4).

% Define the relationships between the residents and floors
above(simo, petko).
above(petko, theo).
above(theo, _).
below(_, ivan).

% Define the rule for determining who lives on which floor
lives_on_floor(Resident, Floor) :-
    resident(Resident),
    floor(Floor),
    (
        (above(AboveResident, Resident), lives_on_floor(AboveResident, AboveFloor), Floor is AboveFloor + 1);
        (below(BelowResident, Resident), lives_on_floor(BelowResident, BelowFloor), Floor is BelowFloor - 1);
        Floor = 1
    ).

% Query the program to get the solution
?- lives_on_floor(Resident, Floor).

