% Define the people
person(man).
person(woman).
person(boy).
person(girl).

% Define the genders
gender(man, male).
gender(woman, female).
gender(boy, male).
gender(girl, female).

% Define the age order
older(man, woman).
older(woman, boy).
older(boy, girl).

% Define the murder relations
murdered(X) :- person(X), not(witness(X)), not(helper(X)).
witness(X) :- person(X), gender(X, G1), helper(Y), gender(Y, G2), G1 \= G2, older(X, Y).
helper(X) :- person(X), gender(X, G1), witness(Y), gender(Y, G2), G1 \= G2, older(X, V), murdered(V), X \= V.
victim(X) :- person(X), not(murdered(X)), not(witness(X)), not(helper(X)).

% Define the constraints
not_same_sex(X, Y) :- gender(X, G1), gender(Y, G2), G1 \= G2.
not_same_sex(witness(W), helper(H)) :- not_same_sex(W, H).
not_same_sex(older(O), witness(W)) :- not_same_sex(O, W).
not_same_gender(youngest(Y), victim(V)) :- gender(Y, G1), gender(V, G2), G1 \= G2.
helper_older_than_victim(H) :- helper(H), older(H, V), murdered(V).
not_youngest(killer) :- murdered(K), not(older(killer, K)).

% Solve the puzzle
solve(Killer) :-
  person(oldest),
  person(youngest),
  victim(V),
  not_same_gender(youngest, V),
  not_same_sex(oldest, witness),
  not_same_sex(witness, helper),
  helper_older_than_victim(helper),
  not_youngest(killer),
  Killer = murdered,
  write('The killer was: '),
  write(Killer), nl.
