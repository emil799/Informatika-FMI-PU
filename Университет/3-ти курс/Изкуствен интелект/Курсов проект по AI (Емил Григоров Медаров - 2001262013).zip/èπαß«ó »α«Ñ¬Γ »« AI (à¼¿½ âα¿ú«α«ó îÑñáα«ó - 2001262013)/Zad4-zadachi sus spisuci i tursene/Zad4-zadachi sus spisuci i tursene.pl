% Define the possible sports and athletes
sport(swimming).
sport(tennis).
sport(volleyball).
sport(chess).

athlete(ivan).
athlete(georgi).
athlete(dimitar).
athlete(stoyan).

% Define the souvenirs for each athlete
souvenir(ivan, racket).
souvenir(georgi, fish).
souvenir(dimitar, ball).
souvenir(stoyan, chess_piece).

% Define the relationships between athletes and their souvenirs
gave_souvenir(X, Y) :-
    athlete(X), athlete(Y),
    X \= Y, souvenir(X, Z), souvenir(Y, Z).

plays_sport(X, Y) :-
    athlete(X), sport(Y),
    not(souvenir(X, Y)).

% Define the constraints based on the information given in the problem
constraint_1 :-
    gave_souvenir(ivan, georgi),
    gave_souvenir(georgi, ivan).

constraint_2 :-
    plays_sport(tennis, chess).

constraint_3 :-
    not(plays_sport(volleyball, swimming)).

constraint_4 :-
    souvenir(stoyan, Z), souvenir(dimitar, Z).

constraint_5 :-
    not(souvenir(X, Y)), athlete(X), sport(Y).

% Define the solution predicate that combines all the constraints
solution(Athletes) :-
    Athletes = [_, _, _, _],
    permutation(Athletes, [ivan, georgi, dimitar, stoyan]),
    constraint_1,
    constraint_2,
    constraint_3,
    constraint_4,
    constraint_5.

% Query the solution predicate to find the solution
?- solution(Athletes).
