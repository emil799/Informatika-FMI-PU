% Define the three people
person(stefan).
person(hristo).
person(dimo).

% Define relationships between people
brother_or_sister(X, Y) :-
    X \= Y,
    sibling(X, Y).
sibling(stefans_sister, stefan).
sibling(stefan, stefans_sister).

% Define age relationships
age(stefan, 3).
age(stefans_sister, 2).
age(hristo, 2).
age(dimo, 4).

% Define marriage relationship
married(dimo, stefans_sister).

% Define the profession of each person
engineer(X) :- person(X), \+ chemist(X), \+ programmer(X).
chemist(X) :- person(X), \+ engineer(X), \+ programmer(X).
programmer(X) :- person(X), \+ engineer(X), \+ chemist(X).

% Define constraints on the ages and relationships
age_constraint(X, Y) :- age(X, A), age(Y, B), A > B.
brother_or_sister_constraint(X) :- \+ brother_or_sister(X, _).
youngest_constraint(X) :- age(X, 2), chemist(X).

% Define the query to solve the puzzle
solve(Engineer, Chemist, Programmer) :-
    engineer(Engineer),
    chemist(Chemist),
    programmer(Programmer),
    age_constraint(Engineer, Dimo),
    age_constraint(Dimo, Chemist),
    married(Dimo, stefans_sister),
    youngest_constraint(Chemist),
    brother_or_sister_constraint(Chemist),
    \+ brother_or_sister(Engineer, Programmer),
    \+ brother_or_sister(Programmer, Chemist).
