% Define the boys
boy(ivo).
boy(emil).
boy(vesco).
boy(plamen).

% Define the sports
sport(gymnastics).
sport(football).
sport(volleyball).
sport(wrestling).

% Define the relationships between the boys and the sports
plays(ivo, Sport) :-
    Sport \= gymnastics,
    Sport \= volleyball.
plays(emil, Sport) :-
    (Sport = wrestling ; Sport = football).
plays(vesco, Sport) :-
    Sport \= volleyball.
plays(plamen, Sport) :-
    Sport \= wrestling.

% Define the relationships between the boys
friends(emil, wrestler).
friends(emil, football).
friends(wrestler, football).

campmates(ivo, wrestler).
campmates(plamen, wrestler).

% Define the logic for finding the solution
solve(Boys) :-
    % There are four boys in total
    length(Boys, 4),
    % Each boy plays a different sport
    permutation(Boys, Sports),
    maplist(plays, Boys, Sports),
    % Ivo and Vesco were at the cinema during a volleyball match
    \+ member(ivo-volleyball, Sports),
    \+ member(vesco-volleyball, Sports),
    % Emil, the wrestler, and the soccer player are friends
    member(emil, Boys),
    member(wrestler, Boys),
    member(football, Sports),
    friends(emil, wrestler),
    friends(emil, football),
    % Plamen and Ivo were in camp with the wrestler
    member(plamen, Boys),
    member(ivo, Boys),
    campmates(plamen, wrestler),
    campmates(ivo, wrestler),
    % Ivo is on a par with the football player and is behind gymnastics
    nth0(IvoIndex, Boys, ivo),
    nth0(FootballIndex, Boys, football),
    nth0(GymnasticsIndex, Sports, gymnastics),
    IvoIndex < FootballIndex,
    IvoIndex > GymnasticsIndex.

% Query the program to find the solution
?- solve(Boys), writeln(Boys).
