% Define the possible professions.
profession(auto_mechanic).
profession(chemist).
profession(builder).
profession(radio_technician).

% Define the possible ages.
age(youngest).
age(second_youngest).
age(second_oldest).
age(oldest).

% Define the possible levels of chess skill.
chess_skill(worst).
chess_skill(second_worst).
chess_skill(second_best).
chess_skill(best).

% Define the possible skiing abilities.
skiing_ability(worst).
skiing_ability(second_worst).
skiing_ability(second_best).
skiing_ability(best).

% Define the possible theater attendance levels.
theater_attendance(least).
theater_attendance(second_least).
theater_attendance(second_most).
theater_attendance(most).

% Define the order of the ages.
before(youngest, second_youngest).
before(second_youngest, second_oldest).
before(second_oldest, oldest).

% Define the order of chess skills.
before(worst, second_worst).
before(second_worst, second_best).
before(second_best, best).

% Define the order of skiing abilities.
before(worst, second_worst).
before(second_worst, second_best).
before(second_best, best).

% Define the order of theater attendance levels.
before(least, second_least).
before(second_least, second_most).
before(second_most, most).

% Define the main predicate that solves the puzzle.
solve(Professions) :-
    % There are four engineers, and each one has a different profession.
    length(Professions, 4),
    permutation([auto_mechanic, chemist, builder, radio_technician], Professions),

    % Angelov beats Todorov at chess but loses to Stoyanov.
    nth0(AngelovIndex, Professions, angelov),
    nth0(TodorovIndex, Professions, todorov),
    nth0(StoyanovIndex, Professions, stoyanov),
    before(chess_skill(best), chess_skill(worst)), % Make sure that there is a best and a worst chess player.
    before(chess_skill(best), chess_skill(second_worst)), % Angelov beats Todorov.
    before(chess_skill(second_worst), chess_skill(worst)), % Angelov loses to Stoyanov.

    % Angelov skis better than the younger engineer.
    nth0(YoungestIndex, Professions, _),
    before(YoungestIndex, AngelovIndex),
    before(skiing_ability(best), skiing_ability(worst)), % Make sure that there is a best and a worst skier.

    % Angelov goes to the theater more often than the engineer who is older than Kostov.
    nth0(KostovIndex, Professions, kostov),
    before(KostovIndex, AngelovIndex),
    before(theater_attendance(most), theater_attendance(least)), % Make sure that there is a most and a least frequent theater-goer.
    before(theater_attendance(most), theater_attendance(second_least)), % Angelov goes to the theater more often than someone.
    before(theater_attendance(second_least), theater_attendance(least)), % The engineer who is older than Kostov goes to the theater less often than someone.

    % The chemist attends the theater more often than the car mechanic but less often than the builder.
    nth0(ChemistIndex, Professions, chemist),
    nth0(CarMechanicIndex, Professions, auto_mechanic),
    nth0(BuilderIndex, Professions, builder),
    before(theater_attendance(second_most).
