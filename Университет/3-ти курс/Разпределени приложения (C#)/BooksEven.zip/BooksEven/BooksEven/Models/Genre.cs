﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using BooksEven.Controllers;

namespace BooksEven.Models
{
    public class Genre
    {
        [Key]
        public int GenreId { get; set; }

        [Display(Name = "Genre")]
        [Required]
        [StringLength(100, MinimumLength = 1)]
        public string GenretName { get; set; }

        public virtual ICollection<Book> Books { get; set; }
    }
}