﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BooksEven.Models;
using PagedList;
using PagedList.Mvc;
using System.ComponentModel.DataAnnotations;

namespace BooksEven.Controllers
{
    public class BooksController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Books
        public ActionResult Index(/*string sortOrder, string currentFilter,*/ string searchString, string authorSearchString, string GenreLesector, int? page)
        {
            ViewBag.SearchString = searchString;
            ViewBag.AuthorSearchString = authorSearchString;
            ViewBag.GenreLesector = GenreLesector;

            var books = db.Books.Include(b => b.Genre).Include(b => b.Writer);

            if (!String.IsNullOrEmpty(searchString) && !String.IsNullOrEmpty(GenreLesector) && !GenreLesector.Equals("-1") && !String.IsNullOrEmpty(authorSearchString)) // ако заглавие, жанр и автор са въведени
            {
                int id = int.Parse(GenreLesector);
                books = books.Where(s => s.Title.Contains(searchString) && (s.Writer.FirstName.Contains(authorSearchString) || s.Writer.LastName.Contains(authorSearchString)) && s.Genre.GenreId == id).OrderBy(s => s.Title); //като сортираме по име на книга, понеже и без това е комбинирано търсене и няма приоритет и без това ще стане мешаница
            }
            else if(String.IsNullOrEmpty(authorSearchString) && !String.IsNullOrEmpty(searchString) && !String.IsNullOrEmpty(GenreLesector) && !GenreLesector.Equals("-1")) //само по заглавие и жанр
            {
                int id = int.Parse(GenreLesector);
                books = books.Where(s => s.Title.Contains(searchString) && s.Genre.GenreId == id).OrderBy(s => s.Title); // като сортираме по заглавие на книгите А->З, понеже всички са от един и същи жанр
            }
            else if((String.IsNullOrEmpty(GenreLesector) || GenreLesector.Equals("-1")) && !String.IsNullOrEmpty(searchString) && !String.IsNullOrEmpty(authorSearchString)) //само по заглавие и автор
            {
                books = books.Where(s => s.Title.Contains(searchString) && (s.Writer.FirstName.Contains(authorSearchString) || s.Writer.LastName.Contains(authorSearchString))).OrderBy(s => s.Writer.LastName); //като сортираме по фамилно име на автора, понеже ще са различни книги от различни автори и ще стане мешаница
            }
            else if(String.IsNullOrEmpty(searchString) && !String.IsNullOrEmpty(GenreLesector) && !GenreLesector.Equals("-1") && !String.IsNullOrEmpty(authorSearchString)) //само по жанр и автор
            {
                int id = int.Parse(GenreLesector);
                books = books.Where(s => s.Genre.GenreId == id && (s.Writer.FirstName.Contains(authorSearchString) || s.Writer.LastName.Contains(authorSearchString))).OrderBy(s => s.Writer.LastName); //като сортираме по фамилно име на автора, понеже всички намерени са от един жанр
            }
            else if(!String.IsNullOrEmpty(searchString)) //само заглавие е въведено
            {
                books = books.Where(s => s.Title.Contains(searchString)).OrderBy(s => s.Title); //като сортираме по заглавие А->З
            }
            else if(!String.IsNullOrEmpty(GenreLesector) && !GenreLesector.Equals("-1")) //само жанр е въведен
            {
                int id = int.Parse(GenreLesector);
                books = books.Where(s => s.Genre.GenreId == id).OrderBy(s => s.Genre.GenretName); //като сортираме по име на жанра
            }
            else if(!String.IsNullOrEmpty(authorSearchString)) //само автор
            {
                books = books.Where(s => s.Writer.FirstName.Contains(authorSearchString) || s.Writer.LastName.Contains(authorSearchString)).OrderBy(s => s.Writer.LastName); //като подреждаме по фамилно име на автора
            }
            else //няма сортировка по нищо
            {
                books = books.OrderBy(x => x.Title); //т.е. сортираме по заглавие всички книги в датабазата
            }

            List<Genre> gL = db.Genres.ToList();
            gL.Insert(0, new Genre() { GenreId = -1, GenretName = "Select genre..." });
            ViewBag.MyList = gL.ToList();

            int pageSize = 10; //за тест дали страницирането работи правилно се променя на 1 и мн лесно се вижда дали си работи с правилните параметри (да не забравя)
            int pageNumber = (page ?? 1);
            return View(books.ToPagedList(pageNumber, pageSize));
        }

        [Authorize] //[Authorize(Roles = "User")]  //мега излишното... всички регистрирани хора падат под Authorize< не е нужно да правя роли
        // GET: Books/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }
        [Authorize(Roles = "Admin")]
        // GET: Books/Create
        public ActionResult Create()
        {
            ViewBag.GenreId = new SelectList(db.Genres, "GenreId", "GenretName");
            ViewBag.WriterId = new SelectList(db.Writers, "WriterId", "FirstName", "LastName");
            return View();
        }

        // POST: Books/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BookId,Title,ReleaseDate,WriterId,GenreId,Description")] Book book)
        {
            if (ModelState.IsValid)
            {
                db.Books.Add(book);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.GenreId = new SelectList(db.Genres, "GenreId", "GenretName", book.GenreId);
            ViewBag.WriterId = new SelectList(db.Writers, "WriterId", "FirstName", "LastName", book.WriterId);
            return View(book);
        }
        [Authorize(Roles = "Admin")]
        // GET: Books/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            ViewBag.GenreId = new SelectList(db.Genres, "GenreId", "GenretName", book.GenreId);
            ViewBag.WriterId = new SelectList(db.Writers, "WriterId", "FirstName", "LastName", book.WriterId);
            return View(book);
        }

        // POST: Books/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BookId,Title,ReleaseDate,WriterId,GenreId,Description")] Book book)
        {
            if (ModelState.IsValid)
            {
                db.Entry(book).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.GenreId = new SelectList(db.Genres, "GenreId", "GenretName", book.GenreId);
            ViewBag.WriterId = new SelectList(db.Writers, "WriterId", "FirstName", "LastName", book.WriterId);
            return View(book);
        }
        [Authorize(Roles = "Admin")]
        // GET: Books/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Book book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        // POST: Books/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Book book = db.Books.Find(id);
            db.Books.Remove(book);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
