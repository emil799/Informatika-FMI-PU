<?php
   $database = "assessment";
   $user = "db_user";
   $password  = "Password1";
   $host = "db";
?>
