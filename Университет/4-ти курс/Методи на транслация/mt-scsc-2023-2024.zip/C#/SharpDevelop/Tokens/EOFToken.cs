
namespace scsc
{
	public class EOFToken: Token
	{
		public EOFToken(int line, int column): base(line, column) {}
	}
}
