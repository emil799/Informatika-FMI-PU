import os
import openai
import json

openai.api_key = "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"

start_sequence = "\nA:"
restart_sequence = "\n\nQ: "

response = openai.Completion.create(
  model="text-davinci-003",
  prompt="What happened at the battle of Stalingrad:",
  temperature=0.5,
  max_tokens=150,
  top_p=1.0,
  frequency_penalty=0.0,
  presence_penalty=0.0
)
print(response)
for resp in response.get("choices"):
    print(resp["text"])
