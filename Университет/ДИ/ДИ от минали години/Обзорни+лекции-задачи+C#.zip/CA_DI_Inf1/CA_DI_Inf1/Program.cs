﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CA_DI_Inf1
{
    class Program
    {
        public class TRace
        {
            public string start_point;
            public int price;
            public int disc_price;
            public DateTime start_time;
            public string company_name;

            public TRace()
            {
                Console.Write("Enter start point: "); 
                start_point = Console.ReadLine();

                Console.Write("Enter price: ");
                price = int.Parse(Console.ReadLine());

                Console.Write("Enter discount price: ");
                disc_price = int.Parse(Console.ReadLine());

                Console.Write("Enter year: ");
                int y = int.Parse(Console.ReadLine());

                Console.Write("Enter month: ");
                int m = int.Parse(Console.ReadLine());

                Console.Write("Enter day: ");
                int d = int.Parse(Console.ReadLine());

                Console.Write("Enter hour: ");
                int h = int.Parse(Console.ReadLine());

                Console.Write("Enter minute: ");
                int min = int.Parse(Console.ReadLine());

                start_time = new DateTime(y, m, d, h, min, 0);

                Console.Write("Enter company name: ");
                company_name = Console.ReadLine();
            }

            public override string ToString()
            {
                string result = start_point + ", " + price + ", " + disc_price + ", "
                    + start_time.ToString() + ", " + company_name;
                return result;
            }

            public int Comp1(TRace r2)
            {
                int r = company_name.CompareTo(r2.start_point);
                if (r != 0) return r;
                if (start_time < r2.start_time) return -1;
                if (start_time == r2.start_time) return 0;
                return 1;
            }
        }

        public class TRaces
        {
            public TRace[] races;
            public List<TCompany> companies; 
            public int num;

            public TRaces()
            {
                do {
                    Console.Write("Enter number of races: ");
                    num = int.Parse(Console.ReadLine());
                } while(num < 1 || num > 1000);

                races = new TRace[num];
                for (int i = 0; i < num; i++)
                {
                    races[i] = new TRace();
                }

                companies = new List<TCompany>();
                bool exists_comp; 

                foreach(TRace r in races)
                {
                    exists_comp = false;
                    foreach(TCompany comp in companies)
                    {
                        if (comp.company_name == r.company_name)
                        {
                            comp.AddDisc(r.price - r.disc_price);
                            exists_comp = true;
                            break;
                        }
                    }
                    if (!exists_comp)
                    {
                        companies.Add(new TCompany(r.company_name, r.price - r.disc_price));
                    }
                }
            }

            public void RacesList1()
            {
                foreach (TRace r in races)
                    Console.WriteLine(r.ToString());
            }

            public void RacesList2()
            {
                TRace min_race;
                int pos;

                for (int i = 0; i < num - 1; i++)
                {
                    min_race = races[i];
                    pos = i;
                    for (int j = i+1; j < num; j++)
                    {
                        // if (min_race.Comp1(races[j]) > 0) или 
                        if (
                            min_race.start_point.CompareTo(races[j].start_point) > 0 ||
                            min_race.start_point == races[j].start_point &&
                            min_race.start_time > races[j].start_time
                            )
                        {
                            min_race = races[j];
                            pos = j;
                        }
                    }
                    // tmp_race = races[i]; races[i] = races[pos]; races[pos] = tmp_race;
                    races[pos] = races[i]; races[i] = min_race;
                }
                RacesList1();

                double sum = 0;
                int n = 0;

                foreach (TRace r in races)
                {
                    if (r.company_name == "HebrosBUS")
                    {
                        sum += r.price - r.disc_price;
                        n++;
                    }
                }

                if (n > 0) Console.WriteLine("Average discount: " + (sum / n).ToString());
            }

            public void RacesList3()
            {
                TRace tmp_race;
                bool flag;

                for(int k = num-2; k>=0; k--)
                {
                    flag = false;
                    for(int i=0; i<=k; i++)
                    {
                        if (races[i].start_time > races[i+1].start_time)
                        {
                            tmp_race = races[i]; races[i] = races[i + 1]; races[i + 1] = tmp_race;
                            flag = true;
                        }
                    }
                    if (!flag) break;
                }

                DateTime d1 = new DateTime(2011, 9, 20);
                DateTime d2 = new DateTime(2011, 9, 26);

                foreach(TRace r in races)
                {
                    if (r.start_point == "Varna" && r.start_time >= d1 && r.start_time < d2)
                    {
                        Console.WriteLine(r.ToString());
                    }
                }
            }

            public void RacesList4()
            {
                double max_disc = -1;
                string comp_name = "";

                foreach(TCompany comp in companies)
                {
                    if (comp.average_discount > max_disc)
                    {
                        max_disc = comp.average_discount;
                        comp_name = comp.company_name;
                    }
                }
                Console.WriteLine("Company with max average discount is: " + comp_name);
                Console.WriteLine();

                TRace tmp_race;
                bool flag;
                for (int k = num - 2; k >= 0; k--)
                {
                    flag = false;
                    for (int i = 0; i <= k; i++)
                    {
                        if (races[i].disc_price > races[i + 1].disc_price)
                        {
                            tmp_race = races[i]; races[i] = races[i + 1]; races[i + 1] = tmp_race;
                            flag = true;
                        }
                    }
                    if (!flag) break;
                }

                int ns = 0;
                foreach(TRace r in races)
                {
                    if (r.start_point == "Sofia")
                    {
                        ns++;
                        Console.WriteLine(r.ToString());
                        if (ns == 3) break;
                    }
                }
            }
        }

        public class TCompany
        {
            public string company_name;
            public double sum_discount;
            public double average_discount;
            public int num_races;

            public TCompany(string cname, double d)
            {
                company_name = cname;
                sum_discount = d;
                average_discount = d;
                num_races = 1;
            }

            public void AddDisc(double dp)
            {
                sum_discount += dp;
                num_races++;
                average_discount = sum_discount / num_races;
            }
        }

        static void Main(string[] args)
        {
            TRaces races = new TRaces();
            Console.WriteLine();
            races.RacesList1();

            races.RacesList2();
            Console.WriteLine();

            races.RacesList3();
            races.RacesList1();

            races.RacesList4();
            
            Console.ReadKey();
        }
    }
}
