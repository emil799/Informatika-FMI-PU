﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// задача – 10 октомври 2011 г.
namespace problem1
{
    class Program
    {
        class TDate
        {
            public int year, month, day, hour, min;
            public TDate(int y, int m, int d, int h, int m2)
            {
                year = y; 
                month = m;
                day = d;
                hour = h;
                min = m2;
            }

            public string Display()
            {
                return year.ToString() + "." + month + "." + day + " " + hour +
                    ":" + min;
            }
            
            public override string ToString()
            {
                return year.ToString() + "." + month + "." + day + " " + hour +
                                    ":" + min;
            }

            public int CompareTo(TDate date2)
            {
                if (year < date2.year) return -1;
                if (year > date2.year) return 1;
                if (month < date2.month) return -1;
                if (month > date2.month) return 1;
                if (day < date2.day) return -1;
                if (day > date2.day) return 1;
                if (hour < date2.hour) return -1;
                if (hour > date2.hour) return 1;
                if (min < date2.min) return -1;
                if (min > date2.min) return 1;
                return 0;     
            }
        }

        class TBus
        {
            public string fromCity;
            public int price;
            public int promoPrice;
            public DateTime raceDate;
            public TDate raceDate2;
            public string busCompany;

            public TBus ()
            {
                do {
                  Console.Write("From City: ");
                  fromCity = Console.ReadLine();
                } while (fromCity.Length > 30);

                Console.Write("Price: ");
                price = int.Parse(Console.ReadLine());

                Console.Write("Promo Price: ");
                promoPrice = int.Parse(Console.ReadLine());

                Console.Write("Bus Company: ");
                busCompany = Console.ReadLine();
               

                int y, m, d, h, min;
                Console.Write("year: ");
                y = int.Parse(Console.ReadLine());

                Console.Write("month: ");
                m = int.Parse(Console.ReadLine());

                Console.Write("day: ");
                d = int.Parse(Console.ReadLine());

                Console.Write("hour: ");
                h = int.Parse(Console.ReadLine());

                Console.Write("minute: ");
                min = int.Parse(Console.ReadLine());

                raceDate = new DateTime(y, m, d, h, min, 0);

                raceDate2 = new TDate(y, m, d, h, min);
            }

            public void Display ()
            {
                Console.Write(fromCity + "; " + price + "; " + promoPrice + "; " +
                   raceDate.ToString() + "; " + 
                   raceDate2.Display() + "; " + busCompany + "\n");  
            }

        }

        class TCompany
        {
            public string name;
            public double max_diff_prices;
            public double common_diff_prices;
            public int num_busses;

            public TCompany(TBus bus)
            {
               name = bus.busCompany;
               max_diff_prices = 0;
               common_diff_prices = bus.price - bus.promoPrice;
               num_busses = 1;
            }

            public void Display()
            {
                Console.WriteLine(name + "; " + max_diff_prices + "; " + num_busses);
                Console.WriteLine();
            }
        }

        class TBuses
        {
            int num;
            TBus[] buses;
            List<TCompany> companies;

            public TBuses(int n)
            {
                num = n;
                buses = new TBus[num];

                for (int i = 0; i < num; i++)
                {
                    buses[i] = new TBus();
                }

                companies = new List<TCompany>();
            }

            public void Display()
            {
                foreach (TBus bus in buses)
                {
                    bus.Display();
                }
                Console.WriteLine();
            }

            public void Sort1()
            {
                for (int i = 0; i < num - 1; i++)
                {
                    for (int j = i + 1; j < num; j++)
                        if (buses[i].fromCity.CompareTo(buses[j].fromCity) > 0 ||
                            buses[i].fromCity.CompareTo(buses[j].fromCity) == 0 &&
                            buses[i].raceDate > buses[j].raceDate)

                        //          buses[i].raceDate2.CompareTo(buses[j].raceDate2) > 0
                        {
                            TBus tmp = buses[i];
                            buses[i] = buses[j];
                            buses[j] = tmp;
                        }
                }
                /*
                                for (int i = 0; i < num - 1; i++)
                                {
                                    TBus minB = buses[i];
                                    int pos = i;

                                    for (int j = i + 1; j < num; j++)
                                        if (buses[j].fromCity.CompareTo(minB.fromCity) < 0 ||
                                            buses[j].fromCity.CompareTo(minB.fromCity) == 0 &&
                                            buses[j].raceDate < minB.raceDate)
                                        {
                                            pos = j;
                                            minB = buses[j];
                                        }
                                    // minB = buses[pos];
                                    buses[pos] = buses[i];
                                    buses[i] = minB;
                                }

                                for (int k = num - 1; k > 0; k--)
                                {
                                    bool sorted = true;
                                    for (int i = 0; i < k; i++)
                                        if (buses[i].fromCity.CompareTo(buses[i + 1].fromCity) > 0 ||
                                            buses[i].fromCity.CompareTo(buses[i + 1].fromCity) == 0 &&
                                            buses[i].raceDate > buses[i + 1].raceDate)
                                        {
                                            TBus tmp = buses[i];
                                            buses[i] = buses[i + 1];
                                            buses[i + 1] = tmp;
                                            sorted = false;
                                        }
                                    if (sorted) break;
                                }
                */
            }

            void Sort2()
            {
                for (int i = 0; i < num - 1; i++)
                {
                    DateTime minDate = buses[i].raceDate;
                    int pos = i;

                    for (int j = i + 1; j < num; j++)
                        if (buses[j].raceDate < minDate)
                        {
                            pos = j;
                            minDate = buses[j].raceDate;
                        }
                    TBus minB = buses[pos];
                    buses[pos] = buses[i];
                    buses[i] = minB;
                }
            }

            public void ListTask3()
            {
                Sort2();
                DateTime d1 = new DateTime(2011, 9, 20, 0, 0, 0);
                DateTime d2 = new DateTime(2011, 9, 26, 0, 0, 0);

                foreach (TBus bus in buses)
                    if (bus.fromCity == "Varna" &&
                        bus.raceDate >= d1 && bus.raceDate <= d2)
                        bus.Display();

                Console.WriteLine();
            }

            public void Task4a()
            {
                foreach (TBus bus in buses)
                {
                    AppendBus(bus);
                }

                foreach (TCompany comp in companies)
                {
                    comp.max_diff_prices =
                        comp.common_diff_prices / comp.num_busses;
                }

                double max_diff_price_comp = 0;
                TCompany max_promo_comp = companies[0];

                foreach (TCompany comp in companies)
                {
                    if (max_diff_price_comp < comp.max_diff_prices)
                    {
                        max_diff_price_comp = comp.max_diff_prices;
                        max_promo_comp = comp;
                    }
                }

                max_promo_comp.Display();

                foreach (TCompany comp in companies)
                {
                    if (max_diff_price_comp == comp.max_diff_prices)
                        comp.Display();
                }
            }

            void AppendBus(TBus bus)
            {
                foreach (TCompany comp in companies)
                {
                    if (comp.name == bus.busCompany)
                    {
                        comp.num_busses++;
                        comp.common_diff_prices += bus.price - bus.promoPrice;
                        return;
                    }
                }
                companies.Add(new TCompany(bus));
            }

            public void Sort3()
            {
                for (int k = num - 1; k > 0; k--)
                {
                    bool sorted = true;
                    for (int i = 0; i < k; i++)
                        if (buses[i].promoPrice > buses[i + 1].promoPrice)
                        {
                            TBus tmp = buses[i];
                            buses[i] = buses[i + 1];
                            buses[i + 1] = tmp;
                            sorted = false;
                        }
                    if (sorted) break;
                }
            }

            public void Task4b()
            {
                int f3 = 0;

                foreach (TBus bus in buses)
                {
                    if (bus.fromCity == "Sofia")
                    {
                        Console.WriteLine(bus.busCompany + "; " + bus.promoPrice);
                        f3++;
                        if (f3 == 3) break;
                    }
                }
            }
            public void Task2b()
            {
                double sum_promo_prices = 0;
                int num_hb = 0;

                foreach (TBus bus in buses)
                {
                    if (bus.busCompany == "HebrosBUS")
                    {
                        sum_promo_prices += bus.promoPrice;
                        num_hb++;
                    }
                }

                double avg_price = sum_promo_prices / num_hb;
                Console.WriteLine("Average promo price for HB is: " +
                    sum_promo_prices / num_hb);
            }
        }

 
        static void Main(string[] args)
        {
            TBuses myBuses = new TBuses(3);

            myBuses.Display();
            myBuses.Sort1();
            myBuses.Display();
            myBuses.Task2b();
            myBuses.ListTask3();
            myBuses.Task4a();
            myBuses.Sort3();
            myBuses.Task4b();

            string a = Console.ReadLine();
        }
    }
}
