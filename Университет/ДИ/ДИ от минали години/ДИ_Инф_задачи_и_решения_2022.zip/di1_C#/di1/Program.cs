﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace di1
{
    class Program
    {
        const int tasks = 5; 

        private class TStudent
        {
            int num;
            public string name;
            public string university;
            public int[] score;
            public int all_scores;

            public TStudent ()
            {
                score = new int[tasks];
            }

            public TStudent (int n, string sname, string univ, int[] sc)
            {
                num = n;
                name = sname;
                university = univ;
                score = new int[tasks];
                for (int i = 0; i < tasks; i++)
                {
                    score[i] = sc[i];
                }
                List<int> tmps = new List<int>(score);
                tmps.Sort();
                all_scores = 0;
                for (int i = 2; i < tasks; i++)
                    all_scores += tmps[i];
            }

            public TStudent(TStudent st)
            {
                num = st.num;
                name = st.name;
                university = st.university;
                score = new int[tasks];
                Array.Copy(st.score, score, tasks);
                all_scores = st.all_scores;
            }

            public void Display()
            {
                Console.WriteLine(name + ", " + university + ", " +
                    all_scores);
            }
        }

        static void Input(TStudent[] std)
        {
            string name;
            string university;
            int[] sc = new int[tasks];

            for (int i = 0; i < std.Length; i++)
            {
                Console.Write("Ime: "); name = Console.ReadLine();
                Console.Write("Univ: "); university = Console.ReadLine();
                for(int k = 0; k<tasks; k++)
                {
                    Console.Write("score[" + k + "] = ");
                    sc[i] = int.Parse(Console.ReadLine());
                }
                std[i] = new TStudent(i+1, name, university, sc);
            }
        }

        static void Sort1(TStudent[] std) // bubble sort
        {
            bool nosw;
            TStudent tmp_st;

            for(int k = std.Length - 1; k>0; k--)
            { 
                nosw = true; 
                for(int i = 0; i<k; i++)
                {       
                    if(std[i].all_scores < std[i+1].all_scores || 
                       std[i].all_scores == std[i+1].all_scores &&
                       std[i].name.CompareTo(std[i+1].name) > 0)
                    {
                        tmp_st = std[i];
                        std[i] = std[i + 1];
                        std[i + 1] = tmp_st;
                        nosw = false;
                    }
                }
                if (nosw) break;
            }
        }

        static void SelectionSort(TStudent[] std)
        {
            TStudent tmp, s1;
            int pos;

            for (int i = 0; i < std.Length - 1; i++)
            {
                s1 = std[i];
                pos = i;

                for (int j = i+1; j < std.Length; j++)
                {
                    if (std[j].all_scores > s1.all_scores ||
                        std[j].all_scores == s1.all_scores &&
                        std[j].name.CompareTo(s1.name) < 0)
                    {
                        s1 = std[j];
                        pos = j;
                    }
                }
                tmp = std[i];
                std[i] = std[pos];
                std[pos] = tmp;

                // или // SwapStudents(ref std[i], ref std[pos]);
            }
        }
        
        static void Display(TStudent[] std)
        {
            for (int i = 0; i < std.Length; i++)
            {
                std[i].Display();
            }
        }

        static void SubTitle3(TStudent[] std, string univ_name)
        {
            int count = 0;
            double sum = 0;

            foreach(TStudent st in std)
            {
                if (st.university == univ_name)
                {
                    count++;
                    sum += st.all_scores;
                }
            }
            if (count > 0)
                Console.WriteLine("average = " + (sum / count).ToString());
        }

        static void SubTitle4(TStudent[] std)
        {
            int[] task_max_sc = new int[tasks];

            foreach (TStudent st in std)
            {
                for(int i=0; i<tasks; i++)
                {
                    if (st.score[i] > task_max_sc[i]) task_max_sc[i] = st.score[i];
                }
            }

            foreach (TStudent st in std)
            {
                for(int i=0; i<tasks; i++)
                {
                    if (st.score[i] == task_max_sc[i])
                    {
                        st.Display(); break;
                    }
                }
            }

        }

        static void SwapStudents(ref TStudent s1, ref TStudent s2)
        {
            TStudent t;
            t = s1;  // new TStudent(s1);
            s1 = s2; // new TStudent(s2);
            s2 = t;  // new TStudent(t);
        }

        static void Main(string[] args)
        {
            int n;
            do
            {
                n = int.Parse(Console.ReadLine());
            } while(n<10 || n>200);


            TStudent[] students = new TStudent[n];

            /* за тестове
            n = 2;
            students[0] = new TStudent(1, "Ivan", "PU", new int[] { 20, 30, 40, 10, 5 });
            students[1] = new TStudent(2, "Peter", "SU", new int[] { 2, 3, 4, 1, 0 });
            */
            
            Input(students);

            Sort1(students);

            Display(students);

            SubTitle3(students, "ПУ \"Паисий Хилендарски\"");

            SubTitle4(students);
/*
            DateTime d1, d2;

            d1 = new DateTime(2016, 1, 1);
            d2 = new DateTime(2016, 1, 2);
*/           

            Console.ReadKey();
        }
    }
}
