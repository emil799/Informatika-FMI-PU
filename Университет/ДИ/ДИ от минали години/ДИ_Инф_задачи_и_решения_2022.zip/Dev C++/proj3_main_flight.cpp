#include <cstdlib>
#include <iostream>

using namespace std;

struct TDate
{
       int day, month, year;
};

struct TFlight
{
       char dest[30];
       int price;
       int dprice;
       TDate fl_date;
       char comp_name[20];
};

TFlight flights[500];
int num_fl;

void displ_fligth(TFlight flight)
{
     cout <<flight.dest <<"; "
          <<flight.price <<"; "
          <<flight.dprice <<"; "
          <<flight.fl_date.day <<"."
          <<flight.fl_date.month <<"."
          <<flight.fl_date.year <<"; "
          <<flight.comp_name <<endl;
}

void displ_fligth1(TFlight flight)
{
     cout <<flight.fl_date.day <<"."
          <<flight.fl_date.month <<"."
          <<flight.fl_date.year <<". "
          <<flight.dest <<" "
          <<flight.comp_name <<" "
          <<flight.dprice <<" eur." <<endl;
}

void enter_flight(TFlight &flight)
{
     cout <<"Fl. name: ";
     cin >>flight.dest;
     
     cout <<"dprice: ";
     cin >>flight.dprice;
     
     cout <<"data: ";
     cin >>flight.fl_date.day >>flight.fl_date.month >>flight.fl_date.year;
     
     cout <<"comp.name: ";
     cin >>flight.comp_name;
}

int datecmp(TDate a, TDate b)
{
    if (a.year < b.year) return -1;
    if (a.year > b.year) return 1;
    if (a.month < b.month) return -1;
    if (a.month > b.month) return 1;
    if (a.day < b.day) return -1;
    if (a.day > b.day) return 1;
    return 0;
}

int main(int argc, char *argv[])
{
    int i, j, pos;
    char stmp[30];
    TFlight fl_tmp;
    float sum_pr=0;
        
    cout <<"Br. poleti: ";
    cin >>num_fl;        
    
    for (i = 0; i < num_fl; i++)
    {
        enter_flight(flights[i]);
    }
    
    for (i = 0; i < num_fl-1; i++)
    {
        strcpy(stmp, flights[i].dest);
        pos = i;
        for (j = i+1; j < num_fl; j++)
        {
            if (strcmp(stmp, flights[j].dest) > 0)
            {
                 strcpy(stmp, flights[j].dest);
                 pos = j;
            }
        }
        fl_tmp = flights[i];
        flights[i] = flights[pos];
        flights[pos] = fl_tmp;
    }
     
    for (i = 0; i < num_fl; i++)
    {
        displ_fligth(flights[i]);
        sum_pr += flights[i].dprice;
    }
    cout <<"Sredna prom. cena: " <<sum_pr/num_fl <<endl;
    
    TDate dtmp;
    
    for (i = 0; i < num_fl-1; i++)
    {
        dtmp = flights[i].fl_date;
        pos = i;
        for (j = i+1; j < num_fl; j++)
        {
            if ( datecmp(dtmp, flights[j].fl_date) > 0)
            {
                 dtmp = flights[j].fl_date;
                 pos = j;
            }
        }
        fl_tmp = flights[i];
        flights[i] = flights[pos];
        flights[pos] = fl_tmp;
    }

    for (i = 0; i < num_fl; i++)
    {
        if (strcmp(flights[i].dest, "London") == 0 ||
            strcmp(flights[i].dest, "Paris") == 0)
        {    
            displ_fligth1(flights[i]);
        }
    }
    
    
              
    system("PAUSE");
    return EXIT_SUCCESS;
}
