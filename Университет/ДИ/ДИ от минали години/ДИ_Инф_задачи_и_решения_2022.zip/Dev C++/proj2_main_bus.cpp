#include <cstdlib>
#include <iostream>

using namespace std;

char *mnames[13] = {
     " ",
     "January",
     "February",
     "March",
     "April",
     "May",
     "June",
     "July",
     "August",
     "September",
     "October",
     "November",
     "December"};

struct MyDate {
    int day, month, year;
    int hour, min;
};
       
struct Bus {
	char from_name[30];
	int price;
	int disc_price;
	struct MyDate my_dt;
    char busCompany[20];
    int mark;
} busses[1000];

struct company_d {
       char comp_name[20];
       double comp_avr_disc;
       int num_r;
} companies[1000];

int date_cmp(struct MyDate a, struct MyDate b)
{
  if (a.year < b.year) return -1;
  if (a.year > b.year) return 1;
  if (a.month < b.month) return -1;
  if (a.month > b.month) return 1;
  if (a.day < b.day) return -1;
  if (a.day > b.day) return 1;
  if (a.hour < b.hour) return -1;
  if (a.hour > b.hour) return 1;
  if (a.min < b.min) return -1;
  if (a.min > b.min) return 1;
  return 0;  
}

int main(int argc, char *argv[])
{
    int n = 100;
    int i, j, k, num_b; 
    double avr_d_price = 0;
   
    num_b = 0;
    for (i = 0; i<n; i++) 
       if ( strcmp(busses[i].busCompany, "���������") == 0 )
       {
           avr_d_price += busses[i].disc_price;
           num_b ++;
       }
       
    if (num_b > 0)
    {
      avr_d_price /= num_b;       
      cout << "The average price for 'HB' is: "
           << avr_d_price <<endl;
    }
    else
      cout << "There is not busses ... " << endl;

    class Bus first_abc, tmp;
    int pos;
    
    for (i = 0; i<n-1; i++)
    {
       pos = i;
       first_abc = busses[i];
       for (j = i+1; j<n; j++)
         if ( strcmp(busses[j].from_name,first_abc.from_name) < 0 ||
              ( strcmp(busses[j].from_name,first_abc.from_name) == 0
                && date_cmp(busses[j].my_dt, first_abc.my_dt) < 0 ) )
            {
                first_abc = busses[j];
                pos = j;
            }
       if (pos > i) {
         tmp = busses[pos]; 
         busses[pos] = busses[i];
         busses[i] = tmp;
       } 
    }
    
    int flag;
    
    for (k = n-1; k > 0; k--)
    {
       flag = 1;    
       for (i = 0; i<k; i++)
       {
         if ( strcmp(busses[i].from_name, busses[i+1].from_name) > 0 ||
              ( strcmp(busses[i].from_name, busses[i+1].from_name) == 0
                && date_cmp(busses[i].my_dt, busses[i+1].my_dt) > 0 ) 
             )
         {
            tmp = busses[i]; 
            busses[i] = busses[i+1];
            busses[i+1] = tmp;
            flag = 0;
         }
       }
       if (flag) break;
    }

    for (i = 0; i<n; i++) 
        cout << busses[i].from_name   <<", "
 	         << busses[i].price       <<", "
             << busses[i].disc_price  <<", "
	         << busses[i].my_dt.day   <<"." 
             << busses[i].my_dt.month <<"."
             << busses[i].my_dt.year  <<", "
	         << busses[i].my_dt.hour  <<":" << busses[i].my_dt.min <<", "
		     << busses[i].busCompany  <<endl;
   
    for (i = 0; i<n-1; i++)
    {
       pos = i;
       first_abc = busses[i];
       for (j = i+1; j<n; j++)
         if ( date_cmp(busses[j].my_dt, first_abc.my_dt) < 0 )
         {
               first_abc = busses[j];
               pos = j;
         }
       if (pos > i) {
         tmp = busses[pos]; 
         busses[pos] = busses[i];
         busses[i] = tmp;
       } 
    }

    MyDate d1, d2;
    
    d1.year = 2011;
    d1.month = 9;
    d1.day = 20;
    d2.year = 2011;
    d2.month = 9;
    d2.day = 25;
    
    for (i = 0; i<n; i++)
      if ( date_cmp(d1, busses[i].my_dt) <= 0 && date_cmp(busses[i].my_dt, d2) <= 0 )
        cout << busses[i].from_name   <<", "
             << busses[i].disc_price  <<", "
	         << busses[i].my_dt.day   <<"." 
             << busses[i].my_dt.month <<"."
             << busses[i].my_dt.year  <<", "
	         << busses[i].my_dt.hour  <<":" << busses[i].my_dt.min <<", "
		     << busses[i].busCompany  <<endl;

    struct Bus busses_B[1000];
    
    k = 0;
    for (i = 0; i<n; i++)
      if ( date_cmp(d1, busses[i].my_dt) <= 0 && date_cmp(busses[i].my_dt, d2) <= 0 )
        busses_B[k++] = busses[i];
    
    int cn = 0;
    
    for (i = 0; i<n; i++) 
    {
        for (j=0; j<cn; j++)
          if (strcmp(busses[i].busCompany,companies[j].comp_name) == 0) break;
        pos = j; 
        if (j == cn) {
          strcpy(companies[pos].comp_name, busses[i].busCompany); 
          companies[pos].comp_avr_disc = 0;
          companies[pos].num_r = 0;
          cn++;
        }              
        companies[pos].comp_avr_disc += busses[i].price - busses[i].disc_price;
        companies[pos].num_r ++;
    }

    for (i = 0; i<cn; i++)
      companies[i].comp_avr_disc /= companies[i].num_r;

    company_d tmp1;
    
    for (k = cn-1; k > 0; k--)
    {
       flag = 1;    
       for (i = 0; i<k; i++)
       {
         if ( companies[i].comp_avr_disc < companies[i+1].comp_avr_disc )
         {
            tmp1 = companies[i]; 
            companies[i] = companies[i+1];
            companies[i+1] = tmp1;
            flag = 0;
         }
       }
       if (flag) break;
    }
    
    double max_disc = companies[0].comp_avr_disc;
    for (i = 0; i<cn; i++)
      if (companies[i].comp_avr_disc == max_disc) 
        cout << companies[i].comp_name <<endl;
      else 
        break;
        

    for (i=n-1; i>0; i--)
        for (j = 0; j<i; j++)
          if ( busses[j].disc_price > 
               busses[j+1].disc_price )
          {
             tmp = busses[j];
             busses[j] = busses[j+1];
             busses[j+1] = tmp;             
          } 
    
    num_b = 0;
         
    for (i=0; i<n-1; i++)
      if (strcmp(busses[i].busCompany, "�����")==0)
      {
         cout <<" " <<endl;
         num_b++;
         if (num_b==3) break;
      }

    
    system("PAUSE");
    return EXIT_SUCCESS;
}
