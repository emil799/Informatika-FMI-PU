#include <cstdlib>
#include <stdlib>     // qsort ?
#include <iostream>

using namespace std;

int N;

struct TStudent 
{
       int number;
       char name[61];
       char university[31];
       int task_points[5];
       int all_points;
} students[200];
    
void EnterStudent(int num)
{
     students[num].number = num+1;
     cout << "Enter a name: ";
     cin.get();
     cin.getline(students[num].name, 61); 

     cout << "Enter university: ";
     cin.getline(students[num].university, 30);
     
     students[num].all_points = 0;
     for (int i=0; i<5; i++)
     {
         cout << "Enter the points for task " << i+1 << ": ";
         cin >> students[num].task_points[i];
         students[num].all_points += students[num].task_points[i];
     }

	 int task_points_2[5];
	 for (int i = 0; i < 5; i++)
		 task_points_2[i] = students[num].task_points[i];
	 qsort(task_points_2); // quick sort
	 students[num].all_points -= (task_points_2[0] + task_points_2[1]);
}
       
void Sort1()
{
     TStudent stud;
//     int max_points = 0;
//     char min_name[61];
     int pos;
     for (int i = 0; i<N-1; i++)
     {
         pos = i;
         stud = students[i];
         for (int j = i+1; j<N; j++)
         {
             if (students[j].all_points > stud.all_points ||
                 students[j].all_points == stud.all_points &&
                 strcmp(students[j].name, stud.name) < 0)
             {
                 pos = j;
                 stud = students[pos];
             }
         }                                 
         students[pos] = students[i];
         students[i] = stud;

		 //stud = student[pos];
		 //students[pos] = students[i];
		 //students[i] = stud;
     }
}

void DisplStudents()
{
     cout <<endl;
     for (int i=0; i<N; i++)
        cout << students[i].name <<", " <<students[i].university <<", " 
             << students[i].all_points <<" points" <<endl;
     cout <<endl;        
}

void DisplStudent(TStudent a)
{
     cout <<a.name <<endl;
}

int main(int argc, char *argv[])
{
    do
    {
         cout << "N = ";
         cin >> N;
    } while (N < 2 || N > 200);
    
    for (int i = 0; i<N; i++)
    {
        EnterStudent(i);
    }
    
    Sort1();
    DisplStudents();
    
    int students_all_points = 0;
    int PU_students = 0;
    
    for (int i = 0; i<N; i++)
        if (strcmp(students[i].university, "���������� �����������") == 0)
        {
            students_all_points += students[i].all_points;
            PU_students ++;
        }
    
    cout <<"Average points are: " 
         << (double)students_all_points / PU_students <<endl;
    
    int max_points;
    
    for (int i=0; i<5; i++)
    {
        max_points = 0;
        for (int k = 0; k < N; k++)
           if (students[k].task_points[i] > max_points)
              max_points = students[k].task_points[i];

        cout <<endl <<"List of students with max points for task " << i+1 <<endl;
                
        for (int k = 0; k < N; k++)
           if (students[k].task_points[i] == max_points)
              DisplStudent(students[k]);
    }
    
    cout << " aaaa";
    system("PAUSE");
    return EXIT_SUCCESS;
}
